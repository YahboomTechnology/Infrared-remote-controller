#include "ti_msp_dl_config.h"
#include "delay.h"
#include "usart.h"
#include "stdio.h"
#include "irremote.h"



int main(void)
{
	int sign;
	
    USART_Init();
	NVIC_EnableIRQ(Signal_INT_IRQN);//ʹ���ⲿ�ж�  Enable external interrupt
	printf("Hello,World!\r\n");
    while (1)
    {
		
    }
}
