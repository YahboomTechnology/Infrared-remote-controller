#ifndef __REMOTE_H
#define __REMOTE_H
#include "ti_msp_dl_config.h" // Device header

#define Irremote_error 0x01

#define GET_OUT         ( ( ( DL_GPIO_readPins(Signal_PORT,Signal_PIN_26_PIN) & Signal_PIN_26_PIN ) > 0 ) ? 1 : 0 )  


void receive_Init(void);
void Infrared_low(uint32_t *low_time);
void Infrared_high(uint32_t *high_time);
uint8_t Guide_Repeat_Judgment(void);
uint8_t Infrared_Data_True(uint8_t *value);
void Receiving_Infrared_Data(void);
//��ȡ���ⷢ�͹���������    Get the command sent by infrared
uint8_t Get_Infrared_Command(void);
//������ⷢ�͹���������    Clear the data sent by infrared
void Clear_Infrared_Command(void);

#endif

