# FIXED

startup_mspm0g351x_ticlang.o: \
 D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/m0p/startup_system_files/ticlang/startup_mspm0g351x_ticlang.c \
 D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/msp.h \
 D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/DeviceFamily.h \
 D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/m0p/mspm0g351x.h \
 D:/ti/mspm0_sdk_2_02_00_05/source/third_party/CMSIS/Core/Include/core_cm0plus.h \
 D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/hw_adc12.h \
 D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/hw_aesadv.h \
 D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/hw_comp.h \
 D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/hw_crcp.h \
 D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/hw_dac12.h \
 D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/hw_dma.h \
 D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/hw_flashctl.h \
 D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/hw_gpio.h \
 D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/hw_gptimer.h \
 D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/hw_i2c.h \
 D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/hw_iomux.h \
 D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/hw_keystorectl.h \
 D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/hw_lfss.h \
 D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/hw_mathacl.h \
 D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/hw_mcan.h \
 D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/hw_rtc.h \
 D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/hw_spi.h \
 D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/hw_trng.h \
 D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/hw_uart.h \
 D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/hw_vref.h \
 D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/hw_wuc.h \
 D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/hw_wwdt.h \
 D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/m0p/hw_factoryregion.h \
 D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/m0p/hw_cpuss.h \
 D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/m0p/hw_debugss.h \
 D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/m0p/hw_sysctl.h \
 D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/m0p/sysctl/hw_sysctl_mspm0gx51x.h
D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/msp.h:
D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/DeviceFamily.h:
D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/m0p/mspm0g351x.h:
D:/ti/mspm0_sdk_2_02_00_05/source/third_party/CMSIS/Core/Include/core_cm0plus.h:
D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/hw_adc12.h:
D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/hw_aesadv.h:
D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/hw_comp.h:
D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/hw_crcp.h:
D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/hw_dac12.h:
D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/hw_dma.h:
D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/hw_flashctl.h:
D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/hw_gpio.h:
D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/hw_gptimer.h:
D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/hw_i2c.h:
D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/hw_iomux.h:
D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/hw_keystorectl.h:
D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/hw_lfss.h:
D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/hw_mathacl.h:
D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/hw_mcan.h:
D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/hw_rtc.h:
D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/hw_spi.h:
D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/hw_trng.h:
D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/hw_uart.h:
D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/hw_vref.h:
D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/hw_wuc.h:
D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/hw_wwdt.h:
D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/m0p/hw_factoryregion.h:
D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/m0p/hw_cpuss.h:
D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/m0p/hw_debugss.h:
D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/m0p/hw_sysctl.h:
D:/ti/mspm0_sdk_2_02_00_05/source/ti/devices/msp/peripherals/m0p/sysctl/hw_sysctl_mspm0gx51x.h:
