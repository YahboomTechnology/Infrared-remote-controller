#include "ti_msp_dl_config.h"  
#include "irremote.h"
#include "delay.h"
#include "usart.h"
#include "stdio.h"

volatile uint32_t gpioA;

typedef struct Infrared_Data{

    uint8_t AddressCode;        //地址码    Address code
    uint8_t AddressInverseCode; //地址反码  Address inverse code
    uint8_t CommandCode;        //命令码    Command code
    uint8_t CommandInverseCode; //命令反码  Command inverse code

}Infrared_Data_Struct;

Infrared_Data_Struct InfraredData;


//获取红外低电平时间    Get infrared low level time
//引导码低电平9ms，引导码：由9ms的低电平+4.5ms的高电平组成。    The boot code low level is 9ms. The boot code is composed of 9ms low level + 4.5ms high level.
void Infrared_low(uint32_t *low_time) {
    uint32_t time_val = 0;
    while(GET_OUT == 0) {
        if(time_val >= 500) {  		// 超过10ms，认为数据接收引导码9ms超时  If the time exceeds 10ms, it is considered that the data receiving boot code 9ms timeout
            *low_time = time_val;	//low_time=500，跳出循环    low_time=500, jump out of the loop
            return;
        }
        delay_us(20);  // 延时20微秒    Delay 20 microseconds
        time_val++;


    }
    *low_time = time_val;
}

//获取红外高电平时间    Get infrared high level time
//引导码高电平9ms，引导码：由9ms的低电平+4.5ms的高电平组成。    Guide code high level 9ms, guide code: consists of 9ms low level + 4.5ms high level.
void Infrared_high(uint32_t *high_time)
{
    uint32_t time_val = 0;
    while( GET_OUT == 1)
    {
        if( time_val >= 250 )        // 超过5ms，认为数据接收引导码4.5ms超时    If the time exceeds 5ms, it is considered that the data receiving boot code 4.5ms timeout
        {
            *high_time = time_val;   //跳出循环，high_time=250  Jump out of the loop, high_time=250
            return;
        }
        delay_us(20);
        time_val++;
    }
    *high_time = time_val;
}
//重复码，它是由一个 9ms 的低电平和一个 2.5ms 的高电平组成。    Repeat code, which is composed of a 9ms low level and a 2.5ms high level.
//当一个红外信号连续发送时，可以通过发送重复码的方式快速发送。  When an infrared signal is sent continuously, it can be sent quickly by sending a repeat code.
//引导码和重复码判断    Guide code and repeat code judgment
uint8_t Guide_Repeat_Judgment(void) {
    uint32_t out_time=0;
    Infrared_low(&out_time);
    if((out_time > 500) || (out_time < 400)) {
        return 1;  // 不是引导码    Not a boot code
    }
    Infrared_high(&out_time);
    if((out_time > 250) || (out_time < 100)) {
        return 1;  // 不是引导码    Not a boot code
    }
    if((out_time > 100) && (out_time < 150)) {
        return 2;  // 重复码    Repeat code
    }
    return 0;  // 引导码    Boot Code
}

//红外数据正确性判断    Infrared data correctness judgment
uint8_t Infrared_Data_True(uint8_t *value) {
    if(value[0] != (uint8_t)(~value[1])) return 0;  // 地址码与地址反码校验 Address code and address inverse code verification
    if(value[2] != (uint8_t)(~value[3])) return 0;  // 命令码与命令反码校验 Command code and command inverse code verification
   printf("%x %x %x %x\r\n", value[0], value[1], value[2], value[3]);
    InfraredData.AddressCode = value[0];
    InfraredData.AddressInverseCode = value[1];
    InfraredData.CommandCode = value[2];
    InfraredData.CommandInverseCode = value[3];
    return 0
		;
}
//接收红外数据  Receive infrared data
/*
数据发送0码：0.56ms低电平+ 0.56ms的高电平   Data sent 0 code: 0.56ms low level + 0.56ms high level
数据发送1码：0.56ms低电平+ 1.68ms的高电平   Data sent 1 code: 0.56ms low level + 1.68ms high level
收到数据位0: 0.56ms低电平+ 0.56ms的高电平   Received data bit 0: 0.56ms low level + 0.56ms high level
收到数据位1: 0.56ms低电平+ 1.68ms的高电平   Received data bit 1: 0.56ms low level + 1.68ms high level
*/
void Receiving_Infrared_Data(void) {
    
    uint16_t Group_num = 0, Data_num = 0;				 // 定义变量，用于存储数据组的索引和数据位的索引  Define variables to store the index of the data group and the index of the data bit
    uint32_t time=0;									 // 定义变量，用于存储时间测量值			    Define variables to store the time measurement value
    uint8_t Bit_data = 0;								 // 定义变量，用于存储单个数据位的值（0或1）    Define variables to store the value of a single data bit (0 or 1)
    uint8_t ir_value[5] = {0};							 // 定义数组，用于存储接收到的红外数据（4个字节的数据 + 1个字节用于其他目的）   Define an array to store the received infrared data (4 bytes of data + 1 byte for other purposes)
    uint8_t Guide_Repeat_Code = 0;						 // 定义变量，用于存储引导码和重复码的判断结果  Define variables to store the judgment results of the boot code and repeat code
    Guide_Repeat_Code = Guide_Repeat_Judgment();		 // 调用函数判断接收到的是否是引导码或重复码	Call the function to determine whether the received code is a boot code or a repeat code
  
    if(Guide_Repeat_Code == 1) {						 // 如果判断结果不是引导码，则打印错误信息并结束函数    If the judgment result is not a boot code, print an error message and end the function
//        printf("err\r\n");
        return;
    }

    for(Group_num = 0; Group_num < 4; Group_num++) {	 // 循环4次，每次处理一个字节的数据	 Loop 4 times, processing one byte of data each time 
        for(Data_num = 0; Data_num < 8; Data_num++) {	 // 循环8次，每次处理一个数据位	     Loop 8 times, processing one data bit each time    
            Infrared_low(&time);						 // 调用函数获取红外低电平时间       Call function to get infrared low level time
			
            if((time > 60) || (time < 20))
			{
				return;// 如果低电平时间不在0.4ms到1.2ms之间，说明数据错误，结束函数    If the low level time is not between 0.4ms and 1.2ms, it means the data is wrong and the function ends.  
			}				        
            time = 0;									 // 重置time变量，为下一次测量做准备   Reset the time variable to prepare for the next measurement
            Infrared_high(&time);						 // 调用函数获取红外高电平时间  Call the function to obtain the infrared high level time
			
            if((time >= 60) && (time < 100)) {			 // 如果高电平时间在1.2ms到2ms之间，说明接收到的是数据位1   If the high level time is between 1.2ms and 2ms, it means that the received data bit 1
                
				Bit_data = 1;
            }
            
            else if((time >= 10) && (time < 50)) {		 // 如果高电平时间在0.2ms到1ms之间，说明接收到的是数据位0   If the high level time is between 0.2ms and 1ms, it means that the received data bit is 0
                Bit_data = 0;
            }
            
            ir_value[Group_num] <<= 1;					 // 将接收到的数据位左移1位，为下一个数据位腾出位置	   Shift the received data bit left by 1 bit to make room for the next data bit
            ir_value[Group_num] |= Bit_data;			 // 将接收到的数据位写入数组	 Write the received data bit into the array
            time=0;										 // 重置time变量，为下一次测量做准备	Reset the time variable to prepare for the next measurement			
        }
    }   
    Infrared_Data_True(ir_value);						 // 调用函数判断接收到的数据是否正确，并保存正确数据	Call the function to determine whether the received data is correct and save the correct data	
}

//获取红外发送过来的命令    Get the command sent by infrared
uint8_t Get_Infrared_Command(void)
{
    return InfraredData.CommandCode;
}
//清除红外发送过来的数据    Clear the data sent by infrared
void Clear_Infrared_Command(void)
{
    InfraredData.CommandCode = 0x00;
}

uint8_t temp2=0;
// 外部中断3的中断服务函数  Interrupt service function of external interrupt 3
void GROUP1_IRQHandler(void)
{   
	    //读取Group1的中断寄存器并清除中断标志位    Read the interrupt register of Group 1 and clear the interrupt flag
    switch( DL_Interrupt_getPendingGroup(DL_INTERRUPT_GROUP_1) )
    {
        //检查是否是端口中断   Check whether the port is interrupted
        case Signal_INT_IIDX:

            if( GET_OUT == 0 )// 如果是低电平   If it is low level
                    Receiving_Infrared_Data(); //接收一次红外数据   Receive infrared data once    
        break;
    }
}
